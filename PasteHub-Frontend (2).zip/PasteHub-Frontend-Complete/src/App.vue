<template>
  <div class="app-layout">
    <AppHeader />

    <div v-if="demoMode" class="demo-banner">
      <div class="shell">
        <span><strong>Demo mode:</strong> data is saved in this browser so the frontend works without the backend.</span>
        <button type="button" @click="navigate('/login')">Use demo account</button>
      </div>
    </div>

    <component
      :is="currentView"
      :key="route.fullPath"
      v-bind="viewProps"
    />

    <footer class="site-footer">
      <div class="shell footer-inner">
        <div class="footer-brand"><span class="brand-mark small-brand-mark">&lt;/&gt;</span> PasteHub</div>
        <p>Built with Vue for the AMD201 Pastebin & Code Snippet Sharer project.</p>
      </div>
    </footer>
  </div>
</template>

<script setup>
import { computed } from 'vue'
import AppHeader from './components/AppHeader.vue'
import CreatePasteView from './views/CreatePasteView.vue'
import PasteView from './views/PasteView.vue'
import PublicPastesView from './views/PublicPastesView.vue'
import DashboardView from './views/DashboardView.vue'
import DiffView from './views/DiffView.vue'
import LoginView from './views/LoginView.vue'
import RegisterView from './views/RegisterView.vue'
import NotFoundView from './views/NotFoundView.vue'
import { useRouter } from './router'
import { isDemoMode } from './services/api'

const { route, navigate } = useRouter()
const demoMode = isDemoMode()

const views = {
  create: CreatePasteView,
  paste: PasteView,
  public: PublicPastesView,
  dashboard: DashboardView,
  diff: DiffView,
  login: LoginView,
  register: RegisterView,
  'not-found': NotFoundView
}

const currentView = computed(() => views[route.value.name] || NotFoundView)
const viewProps = computed(() => route.value.name === 'paste' ? { code: route.value.params.code } : {})
</script>
