import { computed, ref } from 'vue'

const STORAGE_KEY = 'pastehub_session'

function readSession() {
  try {
    return JSON.parse(localStorage.getItem(STORAGE_KEY))
  } catch {
    return null
  }
}

const session = ref(readSession())

export function useAuth() {
  const user = computed(() => session.value?.user || null)
  const token = computed(() => session.value?.token || '')
  const isLoggedIn = computed(() => Boolean(user.value))

  function setSession(newSession) {
    session.value = newSession
    localStorage.setItem(STORAGE_KEY, JSON.stringify(newSession))
  }

  function logout() {
    session.value = null
    localStorage.removeItem(STORAGE_KEY)
  }

  return { user, token, isLoggedIn, setSession, logout }
}
