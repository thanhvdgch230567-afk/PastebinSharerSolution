const PASTES_KEY = 'pastehub_demo_pastes'
const USERS_KEY = 'pastehub_demo_users'
const SESSION_KEY = 'pastehub_session'

const delay = (milliseconds = 180) => new Promise(resolve => setTimeout(resolve, milliseconds))

function read(key, fallback) {
  try {
    const value = localStorage.getItem(key)
    return value ? JSON.parse(value) : fallback
  } catch {
    return fallback
  }
}

function write(key, value) {
  localStorage.setItem(key, JSON.stringify(value))
}

function currentUser() {
  return read(SESSION_KEY, null)?.user || null
}

function createCode() {
  const characters = 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789'
  let code = ''

  for (let index = 0; index < 6; index += 1) {
    code += characters[Math.floor(Math.random() * characters.length)]
  }

  return code
}

function apiError(status, message) {
  const error = new Error(message)
  error.status = status
  return error
}

export function seedMockData() {
  if (!localStorage.getItem(USERS_KEY)) {
    write(USERS_KEY, [
      {
        id: 'demo-user',
        name: 'Demo Student',
        email: 'demo@pastehub.dev',
        password: 'demo123'
      }
    ])
  }

  if (!localStorage.getItem(PASTES_KEY)) {
    const now = Date.now()

    write(PASTES_KEY, [
      {
        code: 'Vue101',
        content: `import { ref } from 'vue'\n\nconst message = ref('Hello PasteHub!')\n\nfunction updateMessage() {\n  message.value = 'Vue is working'\n}`,
        language: 'javascript',
        createdAt: new Date(now - 20 * 60000).toISOString(),
        expiresAt: null,
        isPrivate: false,
        viewCount: 24,
        ownerId: 'demo-user'
      },
      {
        code: 'ApiNET',
        content: `app.MapGet("/api/health", () =>\n{\n    return Results.Ok(new { status = "healthy" });\n});`,
        language: 'csharp',
        createdAt: new Date(now - 3 * 3600000).toISOString(),
        expiresAt: new Date(now + 7 * 86400000).toISOString(),
        isPrivate: false,
        viewCount: 17,
        ownerId: 'demo-user'
      },
      {
        code: 'Sql001',
        content: `SELECT language, COUNT(*) AS total_pastes\nFROM Pastes\nWHERE IsPrivate = FALSE\nGROUP BY language\nORDER BY total_pastes DESC;`,
        language: 'sql',
        createdAt: new Date(now - 86400000).toISOString(),
        expiresAt: null,
        isPrivate: false,
        viewCount: 11,
        ownerId: null
      },
      {
        code: 'PyDemo',
        content: `def create_short_code(length=6):\n    alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"\n    return "".join(random.choice(alphabet) for _ in range(length))`,
        language: 'python',
        createdAt: new Date(now - 2 * 86400000).toISOString(),
        expiresAt: null,
        isPrivate: false,
        viewCount: 8,
        ownerId: null
      },
      {
        code: 'Secret',
        content: `PRIVATE_API_KEY=replace-this-in-production\nDATABASE_HOST=postgres`,
        language: 'bash',
        createdAt: new Date(now - 45 * 60000).toISOString(),
        expiresAt: new Date(now + 86400000).toISOString(),
        isPrivate: true,
        viewCount: 2,
        ownerId: 'demo-user'
      }
    ])
  }
}

export async function register(data) {
  await delay()
  const users = read(USERS_KEY, [])

  if (users.some(user => user.email.toLowerCase() === data.email.toLowerCase())) {
    throw apiError(409, 'An account with this email already exists.')
  }

  const user = {
    id: crypto.randomUUID(),
    name: data.name.trim(),
    email: data.email.trim().toLowerCase(),
    password: data.password
  }

  users.push(user)
  write(USERS_KEY, users)

  return {
    token: `mock-token-${user.id}`,
    user: { id: user.id, name: user.name, email: user.email }
  }
}

export async function login(data) {
  await delay()
  const users = read(USERS_KEY, [])
  const user = users.find(
    item => item.email.toLowerCase() === data.email.trim().toLowerCase() && item.password === data.password
  )

  if (!user) throw apiError(401, 'Email or password is incorrect.')

  return {
    token: `mock-token-${user.id}`,
    user: { id: user.id, name: user.name, email: user.email }
  }
}

export async function createPaste(data) {
  await delay()
  const user = currentUser()

  if (data.isPrivate && !user) {
    throw apiError(401, 'Please sign in before creating a private paste.')
  }

  const pastes = read(PASTES_KEY, [])
  let code = createCode()

  while (pastes.some(paste => paste.code === code)) {
    code = createCode()
  }

  const expirationTimes = {
    '1h': 3600000,
    '1d': 86400000,
    '1w': 604800000
  }

  const paste = {
    code,
    content: data.content,
    language: data.language || 'plaintext',
    createdAt: new Date().toISOString(),
    expiresAt: expirationTimes[data.expiration]
      ? new Date(Date.now() + expirationTimes[data.expiration]).toISOString()
      : null,
    isPrivate: Boolean(data.isPrivate),
    viewCount: 0,
    ownerId: user?.id || null
  }

  pastes.unshift(paste)
  write(PASTES_KEY, pastes)
  return paste
}

export async function getPaste(code) {
  await delay(100)
  const pastes = read(PASTES_KEY, [])
  const paste = pastes.find(item => item.code.toLowerCase() === code.toLowerCase())

  if (!paste) throw apiError(404, 'This paste does not exist.')

  if (paste.expiresAt && new Date(paste.expiresAt) <= new Date()) {
    throw apiError(404, 'This paste has expired.')
  }

  const user = currentUser()
  if (paste.isPrivate && paste.ownerId !== user?.id) {
    throw apiError(403, 'This private paste belongs to another user.')
  }

  paste.viewCount += 1
  write(PASTES_KEY, pastes)
  return { ...paste }
}

export async function getPublicPastes() {
  await delay()
  const now = new Date()

  return read(PASTES_KEY, [])
    .filter(paste => !paste.isPrivate && (!paste.expiresAt || new Date(paste.expiresAt) > now))
    .sort((first, second) => new Date(second.createdAt) - new Date(first.createdAt))
}

export async function getMyPastes() {
  await delay()
  const user = currentUser()
  if (!user) throw apiError(401, 'Please sign in to open your dashboard.')

  const now = new Date()
  return read(PASTES_KEY, [])
    .filter(paste => paste.ownerId === user.id && (!paste.expiresAt || new Date(paste.expiresAt) > now))
    .sort((first, second) => new Date(second.createdAt) - new Date(first.createdAt))
}

export async function deletePaste(code) {
  await delay()
  const user = currentUser()
  const pastes = read(PASTES_KEY, [])
  const paste = pastes.find(item => item.code === code)

  if (!paste) throw apiError(404, 'Paste not found.')
  if (paste.ownerId && paste.ownerId !== user?.id) {
    throw apiError(403, 'You can only delete your own paste.')
  }

  write(PASTES_KEY, pastes.filter(item => item.code !== code))
  return true
}
