import * as mockApi from './mockApi'

const environment = window.PASTEHUB_CONFIG || {}
const useMockApi = environment.VITE_USE_MOCK_API !== 'false'
const apiUrl = environment.VITE_API_URL || 'http://localhost:5231/api'
const CREATED_CODES_KEY = 'pastehub_created_codes'

function getSession() {
  try {
    return JSON.parse(localStorage.getItem('pastehub_session'))
  } catch {
    return null
  }
}

async function request(path, options = {}) {
  const session = getSession()
  const response = await fetch(`${apiUrl}${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(session?.token ? { Authorization: `Bearer ${session.token}` } : {}),
      ...options.headers
    }
  })

  const body = response.status === 204 ? null : await response.json().catch(() => null)

  if (!response.ok) {
    const error = new Error(body?.message || 'The server request failed.')
    error.status = response.status
    error.details = body
    throw error
  }

  return body
}

function rememberCode(code) {
  const codes = JSON.parse(localStorage.getItem(CREATED_CODES_KEY) || '[]')
  localStorage.setItem(CREATED_CODES_KEY, JSON.stringify([...new Set([code, ...codes])]))
}

export function initialiseDemoData() {
  if (useMockApi) mockApi.seedMockData()
}

export function isDemoMode() {
  return useMockApi
}

export async function register(data) {
  if (useMockApi) return mockApi.register(data)
  return request('/auth/register', { method: 'POST', body: JSON.stringify(data) })
}

export async function login(data) {
  if (useMockApi) return mockApi.login(data)
  return request('/auth/login', { method: 'POST', body: JSON.stringify(data) })
}

export async function createPaste(data) {
  const paste = useMockApi
    ? await mockApi.createPaste(data)
    : await request('/pastes', { method: 'POST', body: JSON.stringify(data) })

  rememberCode(paste.code)
  return paste
}

export async function getPaste(code) {
  if (useMockApi) return mockApi.getPaste(code)
  return request(`/pastes/${encodeURIComponent(code)}`)
}

export async function getPublicPastes() {
  if (useMockApi) return mockApi.getPublicPastes()
  return request('/pastes')
}

export async function getMyPastes() {
  if (useMockApi) return mockApi.getMyPastes()

  // Compatibility with the supplied backend, which does not yet have /pastes/mine.
  const codes = JSON.parse(localStorage.getItem(CREATED_CODES_KEY) || '[]')
  const results = await Promise.allSettled(codes.map(code => getPaste(code)))
  return results.filter(result => result.status === 'fulfilled').map(result => result.value)
}

export async function deletePaste(code) {
  if (useMockApi) return mockApi.deletePaste(code)
  await request(`/pastes/${encodeURIComponent(code)}`, { method: 'DELETE' })

  const codes = JSON.parse(localStorage.getItem(CREATED_CODES_KEY) || '[]')
  localStorage.setItem(CREATED_CODES_KEY, JSON.stringify(codes.filter(item => item !== code)))
  return true
}
