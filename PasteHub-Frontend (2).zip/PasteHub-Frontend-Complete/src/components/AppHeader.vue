<template>
  <header class="site-header">
    <div class="shell header-inner">
      <button class="brand" type="button" @click="navigate('/')" aria-label="PasteHub home">
        <span class="brand-mark">&lt;/&gt;</span>
        <span>PasteHub</span>
      </button>

      <nav class="main-nav" aria-label="Main navigation">
        <button :class="{ active: route.name === 'create' }" type="button" @click="navigate('/')">
          New paste
        </button>
        <button :class="{ active: route.name === 'public' }" type="button" @click="navigate('/public')">
          Explore
        </button>
        <button :class="{ active: route.name === 'dashboard' }" type="button" @click="navigate('/dashboard')">
          Dashboard
        </button>
        <button :class="{ active: route.name === 'diff' }" type="button" @click="navigate('/diff')">
          Diff
        </button>
      </nav>

      <div class="header-actions">
        <template v-if="isLoggedIn">
          <button class="user-button" type="button" @click="navigate('/dashboard')">
            <span class="avatar">{{ initials }}</span>
            <span class="user-name">{{ user.name }}</span>
          </button>
          <button class="button button-ghost button-small" type="button" @click="signOut">Sign out</button>
        </template>

        <template v-else>
          <button class="button button-ghost button-small" type="button" @click="navigate('/login')">Sign in</button>
          <button class="button button-primary button-small" type="button" @click="navigate('/register')">Create account</button>
        </template>
      </div>
    </div>
  </header>
</template>

<script setup>
import { computed } from 'vue'
import { useRouter } from '../router'
import { useAuth } from '../stores/auth'

const { route, navigate } = useRouter()
const { user, isLoggedIn, logout } = useAuth()

const initials = computed(() => {
  if (!user.value?.name) return 'U'
  return user.value.name
    .split(' ')
    .slice(0, 2)
    .map(part => part[0])
    .join('')
    .toUpperCase()
})

function signOut() {
  logout()
  navigate('/')
}
</script>
