<template>
  <article class="paste-card">
    <div class="paste-card-top">
      <div>
        <button class="paste-code" type="button" @click="$emit('open', paste.code)">
          /p/{{ paste.code }}
        </button>
        <p class="paste-preview">{{ preview }}</p>
      </div>

      <span class="badge" :class="paste.isPrivate ? 'badge-private' : 'badge-public'">
        {{ paste.isPrivate ? 'Private' : 'Public' }}
      </span>
    </div>

    <div class="paste-meta-row">
      <span class="language-dot"></span>
      <span>{{ languageLabel(paste.language) }}</span>
      <span>•</span>
      <span>{{ formatRelativeDate(paste.createdAt) }}</span>
      <span>•</span>
      <span>{{ paste.viewCount }} views</span>
    </div>

    <div v-if="showDelete" class="paste-card-actions">
      <button class="button button-ghost button-small" type="button" @click="$emit('open', paste.code)">Open</button>
      <button class="button button-danger button-small" type="button" @click="$emit('delete', paste.code)">Delete</button>
    </div>
  </article>
</template>

<script setup>
import { computed } from 'vue'
import { formatRelativeDate, languageLabel } from '../utils/format'

const props = defineProps({
  paste: { type: Object, required: true },
  showDelete: { type: Boolean, default: false }
})

defineEmits(['open', 'delete'])

const preview = computed(() => {
  const cleanText = props.paste.content.replace(/\s+/g, ' ').trim()
  return cleanText.length > 160 ? `${cleanText.slice(0, 160)}…` : cleanText
})
</script>
