import { readonly, ref } from 'vue'

function readRoute() {
  const fullPath = window.location.hash.slice(1) || '/'
  const pasteMatch = fullPath.match(/^\/p\/([^/]+)$/)

  if (pasteMatch) {
    return { name: 'paste', fullPath, params: { code: pasteMatch[1] } }
  }

  const routes = {
    '/': 'create',
    '/public': 'public',
    '/dashboard': 'dashboard',
    '/diff': 'diff',
    '/login': 'login',
    '/register': 'register'
  }

  return {
    name: routes[fullPath] || 'not-found',
    fullPath,
    params: {}
  }
}

const currentRoute = ref(readRoute())

window.addEventListener('hashchange', () => {
  currentRoute.value = readRoute()
  window.scrollTo({ top: 0, behavior: 'smooth' })
})

export function useRouter() {
  function navigate(path) {
    const nextHash = `#${path}`

    if (window.location.hash === nextHash) {
      currentRoute.value = readRoute()
      return
    }

    window.location.hash = path
  }

  return { route: readonly(currentRoute), navigate }
}
