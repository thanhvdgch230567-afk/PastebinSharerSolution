function escapeHtml(value) {
  return value
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;')
}

const languageRules = {
  javascript: /(\/\*[\s\S]*?\*\/|\/\/.*$)|(`(?:\\.|[^`])*`|"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*')|\b(const|let|var|function|return|if|else|for|while|async|await|class|new|import|from|export|try|catch|throw|true|false|null|undefined)\b|\b\d+(?:\.\d+)?\b/gm,
  typescript: /(\/\*[\s\S]*?\*\/|\/\/.*$)|(`(?:\\.|[^`])*`|"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*')|\b(const|let|var|function|return|if|else|for|while|async|await|class|interface|type|enum|public|private|readonly|new|import|from|export|true|false|null|undefined|string|number|boolean)\b|\b\d+(?:\.\d+)?\b/gm,
  csharp: /(\/\*[\s\S]*?\*\/|\/\/.*$)|("(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*')|\b(using|namespace|class|public|private|protected|static|void|string|int|bool|var|new|return|if|else|for|foreach|while|async|await|Task|true|false|null|get|set)\b|\b\d+(?:\.\d+)?\b/gm,
  java: /(\/\*[\s\S]*?\*\/|\/\/.*$)|("(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*')|\b(package|import|class|public|private|protected|static|void|String|int|boolean|new|return|if|else|for|while|try|catch|throws|true|false|null)\b|\b\d+(?:\.\d+)?\b/gm,
  python: /(#.*$)|("""[\s\S]*?"""|'''[\s\S]*?'''|"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*')|\b(def|class|return|if|elif|else|for|while|in|import|from|as|try|except|raise|with|lambda|True|False|None|async|await|and|or|not)\b|\b\d+(?:\.\d+)?\b/gm,
  sql: /(--.*$|\/\*[\s\S]*?\*\/)|("(?:\\.|[^"\\])*"|'(?:''|[^'])*')|\b(SELECT|FROM|WHERE|INSERT|INTO|VALUES|UPDATE|SET|DELETE|CREATE|TABLE|JOIN|LEFT|RIGHT|INNER|ON|GROUP|BY|ORDER|HAVING|LIMIT|AS|AND|OR|NOT|NULL|PRIMARY|KEY|FOREIGN|REFERENCES)\b|\b\d+(?:\.\d+)?\b/gim,
  bash: /(#.*$)|("(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*')|\b(if|then|else|fi|for|in|do|done|case|esac|function|echo|cd|pwd|npm|git|docker|export|sudo)\b|\b\d+(?:\.\d+)?\b/gm
}

export function highlightCode(code, language = 'plaintext') {
  if (!code) return ''
  if (language === 'json') return highlightJson(code)

  if (language === 'html') {
    return escapeHtml(code).replace(
      /(&lt;\/?)([\w-]+)([^&]*?)(\/?&gt;)/g,
      '$1<span class="token-keyword">$2</span><span class="token-string">$3</span>$4'
    )
  }

  const pattern = languageRules[language]
  if (!pattern) return escapeHtml(code)

  let result = ''
  let previousIndex = 0

  code.replace(pattern, (match, comment, stringValue, keyword, offset) => {
    result += escapeHtml(code.slice(previousIndex, offset))

    let className = 'token-number'
    if (comment) className = 'token-comment'
    else if (stringValue) className = 'token-string'
    else if (keyword) className = 'token-keyword'

    result += `<span class="${className}">${escapeHtml(match)}</span>`
    previousIndex = offset + match.length
    return match
  })

  result += escapeHtml(code.slice(previousIndex))
  return result
}

function highlightJson(code) {
  const escaped = escapeHtml(code)

  return escaped.replace(
    /(&quot;(?:\\.|[^&])*?&quot;)(\s*:)?|\b(true|false|null)\b|\b-?\d+(?:\.\d+)?\b/g,
    (match, stringValue, colon, literal) => {
      if (stringValue && colon) return `<span class="token-keyword">${stringValue}</span>${colon}`
      if (stringValue) return `<span class="token-string">${stringValue}</span>`
      if (literal) return `<span class="token-keyword">${literal}</span>`
      return `<span class="token-number">${match}</span>`
    }
  )
}
