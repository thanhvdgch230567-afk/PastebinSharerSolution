export function formatDate(value) {
  if (!value) return 'Never'

  return new Intl.DateTimeFormat('en-GB', {
    dateStyle: 'medium',
    timeStyle: 'short'
  }).format(new Date(value))
}

export function formatRelativeDate(value) {
  const difference = Date.now() - new Date(value).getTime()
  const minutes = Math.floor(difference / 60000)

  if (minutes < 1) return 'just now'
  if (minutes < 60) return `${minutes}m ago`

  const hours = Math.floor(minutes / 60)
  if (hours < 24) return `${hours}h ago`

  const days = Math.floor(hours / 24)
  if (days < 30) return `${days}d ago`

  return formatDate(value)
}

export function formatBytes(bytes) {
  if (bytes < 1024) return `${bytes} B`
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`
}

export function languageLabel(language) {
  const names = {
    plaintext: 'Plain text',
    javascript: 'JavaScript',
    typescript: 'TypeScript',
    csharp: 'C#',
    python: 'Python',
    java: 'Java',
    sql: 'SQL',
    html: 'HTML',
    css: 'CSS',
    json: 'JSON',
    bash: 'Bash'
  }

  return names[language] || language
}
