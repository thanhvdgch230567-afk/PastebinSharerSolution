import { createApp } from 'vue'
import App from './App.vue'
import { initialiseDemoData } from './services/api'

initialiseDemoData()
createApp(App).mount('#app')
