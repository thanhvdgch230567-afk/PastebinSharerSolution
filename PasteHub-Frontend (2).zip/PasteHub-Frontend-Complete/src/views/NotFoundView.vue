<template>
  <main class="shell page-section">
    <section class="panel state-panel">
      <div class="state-icon">404</div>
      <h1>Page not found</h1>
      <p>The page you requested does not exist.</p>
      <button class="button button-primary" type="button" @click="navigate('/')">Return home</button>
    </section>
  </main>
</template>

<script setup>
import { useRouter } from '../router'
const { navigate } = useRouter()
</script>
