<template>
  <main class="shell page-section">
    <section v-if="!isLoggedIn" class="panel auth-required-panel">
      <div class="state-icon">⌁</div>
      <h1>Your paste dashboard</h1>
      <p>Sign in to view, open, and delete the pastes created by your account.</p>
      <div class="button-row center-row">
        <button class="button button-primary" type="button" @click="navigate('/login')">Sign in</button>
        <button class="button button-ghost" type="button" @click="navigate('/register')">Create account</button>
      </div>
    </section>

    <template v-else>
      <section class="page-heading dashboard-heading">
        <div>
          <span class="eyebrow">YOUR WORKSPACE</span>
          <h1 class="page-title">Welcome back, {{ firstName }}</h1>
          <p>Manage every paste you have created.</p>
        </div>
        <button class="button button-primary" type="button" @click="navigate('/')">+ New paste</button>
      </section>

      <section class="stats-grid">
        <article class="panel stat-card">
          <span>Total pastes</span>
          <strong>{{ pastes.length }}</strong>
        </article>
        <article class="panel stat-card">
          <span>Public</span>
          <strong>{{ publicCount }}</strong>
        </article>
        <article class="panel stat-card">
          <span>Private</span>
          <strong>{{ privateCount }}</strong>
        </article>
        <article class="panel stat-card">
          <span>Total views</span>
          <strong>{{ totalViews }}</strong>
        </article>
      </section>

      <section class="toolbar panel dashboard-toolbar">
        <label class="search-box">
          <span>⌕</span>
          <input v-model.trim="search" type="search" placeholder="Search your pastes" />
        </label>

        <div class="segmented-control dashboard-filter">
          <button type="button" :class="{ selected: visibility === 'all' }" @click="visibility = 'all'">All</button>
          <button type="button" :class="{ selected: visibility === 'public' }" @click="visibility = 'public'">Public</button>
          <button type="button" :class="{ selected: visibility === 'private' }" @click="visibility = 'private'">Private</button>
        </div>
      </section>

      <p v-if="message" class="alert alert-success">{{ message }}</p>
      <p v-if="error" class="alert alert-error">{{ error }}</p>

      <section v-if="loading" class="paste-list">
        <div v-for="number in 3" :key="number" class="panel skeleton-card"></div>
      </section>

      <section v-else-if="filteredPastes.length" class="paste-list">
        <PasteCard
          v-for="paste in filteredPastes"
          :key="paste.code"
          :paste="paste"
          show-delete
          @open="openPaste"
          @delete="removePaste"
        />
      </section>

      <section v-else class="panel state-panel compact-state">
        <div class="state-icon">&lt;/&gt;</div>
        <h2>No pastes here yet</h2>
        <p>Create your first paste or change the current filter.</p>
        <button class="button button-primary" type="button" @click="navigate('/')">Create paste</button>
      </section>
    </template>
  </main>
</template>

<script setup>
import { computed, onMounted, ref } from 'vue'
import PasteCard from '../components/PasteCard.vue'
import { deletePaste, getMyPastes } from '../services/api'
import { useRouter } from '../router'
import { useAuth } from '../stores/auth'

const { navigate } = useRouter()
const { user, isLoggedIn } = useAuth()
const pastes = ref([])
const loading = ref(false)
const error = ref('')
const message = ref('')
const search = ref('')
const visibility = ref('all')

const firstName = computed(() => user.value?.name?.split(' ')[0] || 'there')
const publicCount = computed(() => pastes.value.filter(paste => !paste.isPrivate).length)
const privateCount = computed(() => pastes.value.filter(paste => paste.isPrivate).length)
const totalViews = computed(() => pastes.value.reduce((total, paste) => total + paste.viewCount, 0))
const filteredPastes = computed(() => {
  const query = search.value.toLowerCase()

  return pastes.value.filter(paste => {
    const matchesSearch = !query || paste.code.toLowerCase().includes(query) || paste.content.toLowerCase().includes(query)
    const matchesVisibility = visibility.value === 'all'
      || (visibility.value === 'public' && !paste.isPrivate)
      || (visibility.value === 'private' && paste.isPrivate)

    return matchesSearch && matchesVisibility
  })
})

async function loadPastes() {
  if (!isLoggedIn.value) return

  loading.value = true
  error.value = ''

  try {
    pastes.value = await getMyPastes()
  } catch (requestError) {
    error.value = requestError.message || 'Unable to load your pastes.'
  } finally {
    loading.value = false
  }
}

function openPaste(code) {
  navigate(`/p/${code}`)
}

async function removePaste(code) {
  const confirmed = window.confirm(`Delete paste ${code}? This action cannot be undone.`)
  if (!confirmed) return

  try {
    await deletePaste(code)
    pastes.value = pastes.value.filter(paste => paste.code !== code)
    message.value = `Paste ${code} was deleted.`
    window.setTimeout(() => { message.value = '' }, 2200)
  } catch (requestError) {
    error.value = requestError.message || 'Unable to delete the paste.'
  }
}

onMounted(loadPastes)
</script>
