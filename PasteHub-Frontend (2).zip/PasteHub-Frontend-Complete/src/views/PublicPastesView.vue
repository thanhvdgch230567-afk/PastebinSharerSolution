<template>
  <main class="shell page-section">
    <section class="page-heading">
      <div>
        <span class="eyebrow">COMMUNITY</span>
        <h1 class="page-title">Recent public pastes</h1>
        <p>Browse code and text shared publicly by PasteHub users.</p>
      </div>
      <button class="button button-primary" type="button" @click="navigate('/')">+ New paste</button>
    </section>

    <section class="toolbar panel">
      <label class="search-box">
        <span>⌕</span>
        <input v-model.trim="search" type="search" placeholder="Search by code or content" />
      </label>

      <label class="filter-select">
        <span>Language</span>
        <select v-model="selectedLanguage">
          <option value="all">All languages</option>
          <option v-for="language in availableLanguages" :key="language" :value="language">
            {{ languageLabel(language) }}
          </option>
        </select>
      </label>

      <button class="button button-ghost" type="button" :disabled="loading" @click="loadPastes">
        {{ loading ? 'Refreshing…' : 'Refresh' }}
      </button>
    </section>

    <p v-if="error" class="alert alert-error">{{ error }}</p>

    <section v-if="loading" class="paste-list">
      <div v-for="number in 4" :key="number" class="panel skeleton-card"></div>
    </section>

    <section v-else-if="paginatedPastes.length" class="paste-list">
      <PasteCard
        v-for="paste in paginatedPastes"
        :key="paste.code"
        :paste="paste"
        @open="openPaste"
      />
    </section>

    <section v-else class="panel state-panel compact-state">
      <div class="state-icon">⌕</div>
      <h2>No matching pastes</h2>
      <p>Try another search or language filter.</p>
    </section>

    <nav v-if="totalPages > 1" class="pagination" aria-label="Pagination">
      <button class="button button-ghost button-small" type="button" :disabled="page === 1" @click="page -= 1">Previous</button>
      <span>Page {{ page }} of {{ totalPages }}</span>
      <button class="button button-ghost button-small" type="button" :disabled="page === totalPages" @click="page += 1">Next</button>
    </nav>
  </main>
</template>

<script setup>
import { computed, onMounted, ref, watch } from 'vue'
import PasteCard from '../components/PasteCard.vue'
import { getPublicPastes } from '../services/api'
import { useRouter } from '../router'
import { languageLabel } from '../utils/format'

const { navigate } = useRouter()
const pastes = ref([])
const loading = ref(true)
const error = ref('')
const search = ref('')
const selectedLanguage = ref('all')
const page = ref(1)
const pageSize = 6

const availableLanguages = computed(() => [...new Set(pastes.value.map(paste => paste.language))].sort())
const filteredPastes = computed(() => {
  const query = search.value.toLowerCase()

  return pastes.value.filter(paste => {
    const matchesLanguage = selectedLanguage.value === 'all' || paste.language === selectedLanguage.value
    const matchesSearch = !query || paste.code.toLowerCase().includes(query) || paste.content.toLowerCase().includes(query)
    return matchesLanguage && matchesSearch
  })
})
const totalPages = computed(() => Math.max(1, Math.ceil(filteredPastes.value.length / pageSize)))
const paginatedPastes = computed(() => {
  const start = (page.value - 1) * pageSize
  return filteredPastes.value.slice(start, start + pageSize)
})

watch([search, selectedLanguage], () => {
  page.value = 1
})

async function loadPastes() {
  error.value = ''
  loading.value = true

  try {
    pastes.value = await getPublicPastes()
  } catch (requestError) {
    error.value = requestError.message || 'Unable to load public pastes.'
  } finally {
    loading.value = false
  }
}

function openPaste(code) {
  navigate(`/p/${code}`)
}

onMounted(loadPastes)
</script>
