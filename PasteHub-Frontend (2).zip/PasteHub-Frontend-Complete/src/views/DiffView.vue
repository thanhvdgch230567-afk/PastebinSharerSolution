<template>
  <main class="shell page-section">
    <section class="page-heading">
      <div>
        <span class="eyebrow">DISTINCTION FEATURE</span>
        <h1 class="page-title">Compare two pastes</h1>
        <p>Enter two paste codes to compare changed lines side by side.</p>
      </div>
    </section>

    <form class="panel diff-form" @submit.prevent="comparePastes">
      <label class="field">
        <span>Original paste code</span>
        <input v-model.trim="firstCode" type="text" placeholder="Example: Vue101" required />
      </label>
      <div class="diff-arrow">→</div>
      <label class="field">
        <span>Updated paste code</span>
        <input v-model.trim="secondCode" type="text" placeholder="Example: ApiNET" required />
      </label>
      <button class="button button-primary" type="submit" :disabled="loading">
        {{ loading ? 'Comparing…' : 'Compare' }}
      </button>
    </form>

    <p v-if="error" class="alert alert-error">{{ error }}</p>

    <section v-if="rows.length" class="panel diff-panel">
      <div class="diff-header">
        <div><strong>/p/{{ firstPaste.code }}</strong><span>{{ languageLabel(firstPaste.language) }}</span></div>
        <div><strong>/p/{{ secondPaste.code }}</strong><span>{{ languageLabel(secondPaste.language) }}</span></div>
      </div>

      <div class="diff-body">
        <div v-for="row in rows" :key="row.number" class="diff-row" :class="`diff-${row.status}`">
          <div class="diff-cell">
            <span class="diff-line-number">{{ row.left === null ? '' : row.number }}</span>
            <code>{{ row.left ?? '' }}</code>
          </div>
          <div class="diff-cell">
            <span class="diff-line-number">{{ row.right === null ? '' : row.number }}</span>
            <code>{{ row.right ?? '' }}</code>
          </div>
        </div>
      </div>

      <div class="diff-summary">
        <span><i class="summary-dot same-dot"></i>{{ summary.same }} unchanged</span>
        <span><i class="summary-dot changed-dot"></i>{{ summary.changed }} changed</span>
        <span><i class="summary-dot added-dot"></i>{{ summary.added }} added</span>
        <span><i class="summary-dot removed-dot"></i>{{ summary.removed }} removed</span>
      </div>
    </section>

    <section v-else class="panel diff-help">
      <h2>Try the demo codes</h2>
      <p>Use <button type="button" @click="useDemo">Vue101 and ApiNET</button> to preview the side-by-side comparison.</p>
      <small>This simple frontend comparison matches lines by position so the code stays easy to understand.</small>
    </section>
  </main>
</template>

<script setup>
import { computed, ref } from 'vue'
import { getPaste } from '../services/api'
import { languageLabel } from '../utils/format'

const firstCode = ref('')
const secondCode = ref('')
const firstPaste = ref(null)
const secondPaste = ref(null)
const loading = ref(false)
const error = ref('')

const rows = computed(() => {
  if (!firstPaste.value || !secondPaste.value) return []

  const leftLines = firstPaste.value.content.split('\n')
  const rightLines = secondPaste.value.content.split('\n')
  const length = Math.max(leftLines.length, rightLines.length)

  return Array.from({ length }, (_, index) => {
    const left = index < leftLines.length ? leftLines[index] : null
    const right = index < rightLines.length ? rightLines[index] : null

    let status = 'same'
    if (left === null) status = 'added'
    else if (right === null) status = 'removed'
    else if (left !== right) status = 'changed'

    return { number: index + 1, left, right, status }
  })
})

const summary = computed(() => rows.value.reduce((totals, row) => {
  totals[row.status] += 1
  return totals
}, { same: 0, changed: 0, added: 0, removed: 0 }))

function useDemo() {
  firstCode.value = 'Vue101'
  secondCode.value = 'ApiNET'
  comparePastes()
}

async function comparePastes() {
  error.value = ''
  firstPaste.value = null
  secondPaste.value = null

  try {
    loading.value = true
    const [first, second] = await Promise.all([
      getPaste(firstCode.value),
      getPaste(secondCode.value)
    ])
    firstPaste.value = first
    secondPaste.value = second
  } catch (requestError) {
    error.value = requestError.message || 'One of the paste codes could not be loaded.'
  } finally {
    loading.value = false
  }
}
</script>
