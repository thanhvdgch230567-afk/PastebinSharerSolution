<template>
  <main>
    <section class="hero shell">
      <div class="hero-copy">
        <span class="eyebrow">PASTEBIN & CODE SNIPPET SHARER</span>
        <h1>Share code in seconds.</h1>
        <p>Create a clean, shareable link for code, logs, configuration files, or plain text.</p>
      </div>

      <div class="hero-stats" aria-label="Application features">
        <div><strong>500 KB</strong><span>maximum size</span></div>
        <div><strong>6 chars</strong><span>short link</span></div>
        <div><strong>4 options</strong><span>expiry control</span></div>
      </div>
    </section>

    <section class="shell page-grid create-grid">
      <form class="panel editor-panel" @submit.prevent="submitPaste">
        <div class="panel-heading">
          <div>
            <h2>Create a new paste</h2>
            <p>Choose a language, expiry time, and visibility.</p>
          </div>
          <span class="status-pill"><span class="status-dot"></span> Ready</span>
        </div>

        <div class="editor-toolbar">
          <label class="field compact-field">
            <span>Language</span>
            <select v-model="form.language">
              <option v-for="language in languages" :key="language.value" :value="language.value">
                {{ language.label }}
              </option>
            </select>
          </label>

          <label class="field compact-field">
            <span>Expires</span>
            <select v-model="form.expiration">
              <option value="1h">1 hour</option>
              <option value="1d">1 day</option>
              <option value="1w">1 week</option>
              <option value="never">Never</option>
            </select>
          </label>

          <div class="field visibility-field">
            <span>Visibility</span>
            <div class="segmented-control">
              <button
                type="button"
                :class="{ selected: !form.isPrivate }"
                @click="form.isPrivate = false"
              >
                Public
              </button>
              <button
                type="button"
                :class="{ selected: form.isPrivate }"
                @click="selectPrivate"
              >
                Private
              </button>
            </div>
          </div>
        </div>

        <div class="code-editor-wrap">
          <div class="editor-gutter" aria-hidden="true">1</div>
          <textarea
            v-model="form.content"
            class="code-editor"
            rows="18"
            spellcheck="false"
            maxlength="512000"
            placeholder="Paste your code or text here..."
          ></textarea>
        </div>

        <div class="editor-footer">
          <div class="editor-info">
            <span>{{ lineCount }} lines</span>
            <span>•</span>
            <span :class="{ 'text-danger': isTooLarge }">{{ formattedSize }} / 500 KB</span>
          </div>

          <div class="editor-actions">
            <button class="button button-ghost" type="button" @click="insertExample">Use example</button>
            <button class="button button-primary" type="submit" :disabled="loading || !canSubmit">
              {{ loading ? 'Creating…' : 'Create paste' }}
              <span aria-hidden="true">→</span>
            </button>
          </div>
        </div>

        <p v-if="error" class="alert alert-error">{{ error }}</p>
      </form>

      <aside class="side-column">
        <section class="panel info-panel">
          <h3>How it works</h3>
          <ol class="steps-list">
            <li><span>1</span><div><strong>Paste content</strong><small>Add code, notes, or logs.</small></div></li>
            <li><span>2</span><div><strong>Choose settings</strong><small>Select language, expiry, and privacy.</small></div></li>
            <li><span>3</span><div><strong>Share the link</strong><small>Copy the generated short URL.</small></div></li>
          </ol>
        </section>

        <section class="panel info-panel security-panel">
          <span class="info-icon">⌁</span>
          <div>
            <h3>Private pastes</h3>
            <p v-if="isLoggedIn">Private pastes are only visible in your signed-in account.</p>
            <p v-else>Sign in first to create private pastes and manage them in your dashboard.</p>
            <button v-if="!isLoggedIn" class="text-button" type="button" @click="navigate('/login')">Sign in now →</button>
          </div>
        </section>
      </aside>
    </section>
  </main>
</template>

<script setup>
import { computed, reactive, ref } from 'vue'
import { createPaste } from '../services/api'
import { useRouter } from '../router'
import { useAuth } from '../stores/auth'
import { formatBytes } from '../utils/format'

const { navigate } = useRouter()
const { isLoggedIn } = useAuth()

const languages = [
  { value: 'plaintext', label: 'Plain text' },
  { value: 'javascript', label: 'JavaScript' },
  { value: 'typescript', label: 'TypeScript' },
  { value: 'csharp', label: 'C#' },
  { value: 'python', label: 'Python' },
  { value: 'java', label: 'Java' },
  { value: 'sql', label: 'SQL' },
  { value: 'html', label: 'HTML' },
  { value: 'css', label: 'CSS' },
  { value: 'json', label: 'JSON' },
  { value: 'bash', label: 'Bash' }
]

const form = reactive({
  content: '',
  language: 'javascript',
  expiration: '1d',
  isPrivate: false
})

const loading = ref(false)
const error = ref('')

const contentBytes = computed(() => new TextEncoder().encode(form.content).length)
const formattedSize = computed(() => formatBytes(contentBytes.value))
const isTooLarge = computed(() => contentBytes.value > 512000)
const lineCount = computed(() => (form.content ? form.content.split('\n').length : 1))
const canSubmit = computed(() => Boolean(form.content.trim()) && !isTooLarge.value)

function selectPrivate() {
  if (!isLoggedIn.value) {
    navigate('/login')
    return
  }

  form.isPrivate = true
}

function insertExample() {
  form.language = 'javascript'
  form.content = `async function createPaste(content) {\n  const response = await fetch('/api/pastes', {\n    method: 'POST',\n    headers: { 'Content-Type': 'application/json' },\n    body: JSON.stringify({ content, language: 'javascript' })\n  })\n\n  return response.json()\n}`
}

async function submitPaste() {
  error.value = ''

  if (!form.content.trim()) {
    error.value = 'Paste content cannot be empty.'
    return
  }

  if (isTooLarge.value) {
    error.value = 'Paste content must not exceed 500 KB.'
    return
  }

  try {
    loading.value = true
    const paste = await createPaste({ ...form })
    navigate(`/p/${paste.code}`)
  } catch (requestError) {
    error.value = requestError.message || 'Unable to create the paste.'
  } finally {
    loading.value = false
  }
}
</script>
