<template>
  <main class="auth-page shell">
    <section class="auth-copy">
      <span class="eyebrow">CREATE YOUR ACCOUNT</span>
      <h1>Keep every snippet organised.</h1>
      <p>Create private pastes, review view counts, and remove old content from your dashboard.</p>

      <ul class="feature-checklist">
        <li><span>✓</span> Private paste access</li>
        <li><span>✓</span> Personal paste dashboard</li>
        <li><span>✓</span> Expiry and visibility controls</li>
      </ul>
    </section>

    <form class="panel auth-card" @submit.prevent="submitRegister">
      <div class="auth-card-heading">
        <span class="brand-mark large-brand-mark">&lt;/&gt;</span>
        <h2>Create an account</h2>
        <p>It only takes a few seconds.</p>
      </div>

      <label class="field">
        <span>Display name</span>
        <input v-model.trim="form.name" type="text" autocomplete="name" placeholder="Your name" required minlength="2" />
      </label>

      <label class="field">
        <span>Email address</span>
        <input v-model.trim="form.email" type="email" autocomplete="email" placeholder="you@example.com" required />
      </label>

      <label class="field">
        <span>Password</span>
        <input v-model="form.password" type="password" autocomplete="new-password" placeholder="At least 6 characters" required minlength="6" />
      </label>

      <p v-if="error" class="alert alert-error">{{ error }}</p>

      <button class="button button-primary button-full" type="submit" :disabled="loading">
        {{ loading ? 'Creating account…' : 'Create account' }}
      </button>

      <p class="auth-switch">Already have an account? <button type="button" @click="navigate('/login')">Sign in</button></p>
    </form>
  </main>
</template>

<script setup>
import { reactive, ref } from 'vue'
import { register } from '../services/api'
import { useAuth } from '../stores/auth'
import { useRouter } from '../router'

const { setSession } = useAuth()
const { navigate } = useRouter()
const loading = ref(false)
const error = ref('')
const form = reactive({ name: '', email: '', password: '' })

async function submitRegister() {
  error.value = ''

  if (form.password.length < 6) {
    error.value = 'Password must contain at least 6 characters.'
    return
  }

  try {
    loading.value = true
    const session = await register(form)
    setSession(session)
    navigate('/dashboard')
  } catch (requestError) {
    error.value = requestError.message || 'Unable to create the account.'
  } finally {
    loading.value = false
  }
}
</script>
