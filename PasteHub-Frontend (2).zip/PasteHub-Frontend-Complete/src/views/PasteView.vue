<template>
  <main class="shell page-section">
    <div v-if="loading" class="panel state-panel">
      <span class="spinner"></span>
      <h2>Loading paste…</h2>
      <p>Please wait while the content is retrieved.</p>
    </div>

    <div v-else-if="error" class="panel state-panel">
      <div class="state-icon">!</div>
      <h2>{{ errorTitle }}</h2>
      <p>{{ error }}</p>
      <button class="button button-primary" type="button" @click="navigate('/')">Create a new paste</button>
    </div>

    <template v-else-if="paste">
      <section class="paste-title-row">
        <div>
          <div class="breadcrumb">
            <button type="button" @click="navigate('/public')">Explore</button>
            <span>/</span>
            <strong>{{ paste.code }}</strong>
          </div>
          <h1 class="page-title">Paste <span class="mono">{{ paste.code }}</span></h1>
          <div class="paste-details">
            <span class="badge" :class="paste.isPrivate ? 'badge-private' : 'badge-public'">
              {{ paste.isPrivate ? 'Private' : 'Public' }}
            </span>
            <span>{{ languageLabel(paste.language) }}</span>
            <span>•</span>
            <span>Created {{ formatRelativeDate(paste.createdAt) }}</span>
            <span>•</span>
            <span>{{ paste.viewCount }} views</span>
          </div>
        </div>

        <div class="page-actions">
          <button class="button button-ghost" type="button" @click="copyContent">
            {{ copiedContent ? 'Copied!' : 'Copy code' }}
          </button>
          <button class="button button-primary" type="button" @click="copyLink">
            {{ copiedLink ? 'Link copied!' : 'Copy link' }}
          </button>
        </div>
      </section>

      <section class="panel code-panel">
        <div class="code-panel-header">
          <div>
            <span class="file-icon">&lt;/&gt;</span>
            <strong>{{ paste.code }}.{{ fileExtension }}</strong>
          </div>
          <div class="code-panel-meta">
            <span>{{ paste.content.split('\n').length }} lines</span>
            <span>•</span>
            <span>Expires {{ paste.expiresAt ? formatDate(paste.expiresAt) : 'never' }}</span>
          </div>
        </div>

        <div class="code-viewer">
          <pre class="line-numbers" aria-hidden="true"><span v-for="number in lineNumbers" :key="number">{{ number }}</span></pre>
          <pre class="highlighted-code"><code v-html="highlightedContent"></code></pre>
        </div>
      </section>

      <section class="share-bar">
        <div>
          <strong>Share this paste</strong>
          <span>{{ currentUrl }}</span>
        </div>
        <button class="button button-ghost button-small" type="button" @click="copyLink">Copy URL</button>
      </section>
    </template>
  </main>
</template>

<script setup>
import { computed, onMounted, ref } from 'vue'
import { getPaste } from '../services/api'
import { useRouter } from '../router'
import { formatDate, formatRelativeDate, languageLabel } from '../utils/format'
import { highlightCode } from '../utils/highlight'

const props = defineProps({
  code: { type: String, required: true }
})

const { navigate } = useRouter()
const paste = ref(null)
const loading = ref(true)
const error = ref('')
const errorStatus = ref(0)
const copiedContent = ref(false)
const copiedLink = ref(false)

const highlightedContent = computed(() => highlightCode(paste.value?.content || '', paste.value?.language))
const lineNumbers = computed(() => {
  const total = paste.value?.content?.split('\n').length || 1
  return Array.from({ length: total }, (_, index) => index + 1)
})
const currentUrl = computed(() => window.location.href)
const errorTitle = computed(() => {
  if (errorStatus.value === 403) return 'Private paste'
  if (errorStatus.value === 404) return 'Paste not found'
  return 'Unable to load paste'
})

const fileExtension = computed(() => {
  const extensions = {
    plaintext: 'txt', javascript: 'js', typescript: 'ts', csharp: 'cs', python: 'py',
    java: 'java', sql: 'sql', html: 'html', css: 'css', json: 'json', bash: 'sh'
  }
  return extensions[paste.value?.language] || 'txt'
})

async function loadPaste() {
  try {
    paste.value = await getPaste(props.code)
  } catch (requestError) {
    error.value = requestError.message || 'The paste could not be loaded.'
    errorStatus.value = requestError.status || 0
  } finally {
    loading.value = false
  }
}

async function copyText(value, type) {
  try {
    await navigator.clipboard.writeText(value)
    if (type === 'content') copiedContent.value = true
    if (type === 'link') copiedLink.value = true

    window.setTimeout(() => {
      copiedContent.value = false
      copiedLink.value = false
    }, 1600)
  } catch {
    error.value = 'Your browser did not allow clipboard access.'
  }
}

function copyContent() {
  copyText(paste.value.content, 'content')
}

function copyLink() {
  copyText(window.location.href, 'link')
}

onMounted(loadPaste)
</script>
