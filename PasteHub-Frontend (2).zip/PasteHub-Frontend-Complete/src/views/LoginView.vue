<template>
  <main class="auth-page shell">
    <section class="auth-copy">
      <span class="eyebrow">WELCOME BACK</span>
      <h1>Sign in to manage private pastes.</h1>
      <p>Your dashboard keeps your public and private snippets in one place.</p>

      <div class="demo-account">
        <strong>Demo account</strong>
        <span>Email: demo@pastehub.dev</span>
        <span>Password: demo123</span>
        <button class="text-button" type="button" @click="fillDemo">Fill demo details →</button>
      </div>
    </section>

    <form class="panel auth-card" @submit.prevent="submitLogin">
      <div class="auth-card-heading">
        <span class="brand-mark large-brand-mark">&lt;/&gt;</span>
        <h2>Sign in to PasteHub</h2>
        <p>Enter your account details below.</p>
      </div>

      <label class="field">
        <span>Email address</span>
        <input v-model.trim="form.email" type="email" autocomplete="email" placeholder="you@example.com" required />
      </label>

      <label class="field">
        <span>Password</span>
        <input v-model="form.password" type="password" autocomplete="current-password" placeholder="At least 6 characters" required />
      </label>

      <p v-if="error" class="alert alert-error">{{ error }}</p>

      <button class="button button-primary button-full" type="submit" :disabled="loading">
        {{ loading ? 'Signing in…' : 'Sign in' }}
      </button>

      <p class="auth-switch">New to PasteHub? <button type="button" @click="navigate('/register')">Create an account</button></p>
    </form>
  </main>
</template>

<script setup>
import { reactive, ref } from 'vue'
import { login } from '../services/api'
import { useAuth } from '../stores/auth'
import { useRouter } from '../router'

const { setSession } = useAuth()
const { navigate } = useRouter()
const loading = ref(false)
const error = ref('')
const form = reactive({ email: '', password: '' })

function fillDemo() {
  form.email = 'demo@pastehub.dev'
  form.password = 'demo123'
}

async function submitLogin() {
  error.value = ''

  try {
    loading.value = true
    const session = await login(form)
    setSession(session)
    navigate('/dashboard')
  } catch (requestError) {
    error.value = requestError.message || 'Unable to sign in.'
  } finally {
    loading.value = false
  }
}
</script>
