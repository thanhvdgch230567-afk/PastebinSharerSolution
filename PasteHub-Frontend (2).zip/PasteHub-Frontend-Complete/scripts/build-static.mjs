import fs from 'node:fs'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { compileScript, compileTemplate, parse } from '@vue/compiler-sfc'

const projectRoot = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const sourceRoot = path.join(projectRoot, 'src')
const outputRoot = path.join(projectRoot, 'dist')

fs.rmSync(outputRoot, { recursive: true, force: true })
fs.mkdirSync(path.join(outputRoot, 'src'), { recursive: true })
fs.mkdirSync(path.join(outputRoot, 'vendor'), { recursive: true })

function readEnvironmentFile() {
  const values = {}
  const environmentPath = path.join(projectRoot, '.env')
  const fallbackPath = path.join(projectRoot, '.env.example')
  const selectedPath = fs.existsSync(environmentPath) ? environmentPath : fallbackPath

  if (!fs.existsSync(selectedPath)) return values

  for (const line of fs.readFileSync(selectedPath, 'utf8').split(/\r?\n/)) {
    const cleanLine = line.trim()
    if (!cleanLine || cleanLine.startsWith('#') || !cleanLine.includes('=')) continue
    const separatorIndex = cleanLine.indexOf('=')
    values[cleanLine.slice(0, separatorIndex).trim()] = cleanLine.slice(separatorIndex + 1).trim()
  }

  return values
}

function fixLocalImports(code) {
  return code.replace(
    /(from\s+['"]|import\s+['"])(\.{1,2}\/[^'"]+)(['"])/g,
    (fullMatch, before, importPath, after) => {
      if (importPath.endsWith('.vue')) {
        return `${before}${importPath.slice(0, -4)}.js${after}`
      }

      if (!path.extname(importPath)) {
        return `${before}${importPath}.js${after}`
      }

      return fullMatch
    }
  )
}

function compileVueFile(inputPath, outputPath) {
  const filename = path.relative(projectRoot, inputPath).replaceAll('\\', '/')
  const source = fs.readFileSync(inputPath, 'utf8')
  const { descriptor, errors } = parse(source, { filename })

  if (errors.length) throw new Error(`Unable to parse ${filename}: ${errors.join('\n')}`)

  const id = Buffer.from(filename).toString('hex').slice(0, 8)
  let scriptCode = 'const __sfc__ = {}\n'
  let bindings = {}

  if (descriptor.script || descriptor.scriptSetup) {
    const script = compileScript(descriptor, { id, genDefaultAs: '__sfc__' })
    scriptCode = script.content
    bindings = script.bindings
  }

  if (!descriptor.template) throw new Error(`${filename} does not contain a template.`)

  const template = compileTemplate({
    source: descriptor.template.content,
    filename,
    id,
    compilerOptions: { bindingMetadata: bindings }
  })

  if (template.errors.length) {
    throw new Error(`Unable to compile ${filename}: ${template.errors.join('\n')}`)
  }

  const finalCode = fixLocalImports(
    `${scriptCode}\n${template.code}\n__sfc__.render = render\nexport default __sfc__\n`
  )

  fs.mkdirSync(path.dirname(outputPath), { recursive: true })
  fs.writeFileSync(outputPath, finalCode)
}

function processDirectory(directory) {
  for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
    const inputPath = path.join(directory, entry.name)
    const relativePath = path.relative(sourceRoot, inputPath)

    if (entry.isDirectory()) {
      processDirectory(inputPath)
      continue
    }

    if (entry.name.endsWith('.vue')) {
      compileVueFile(inputPath, path.join(outputRoot, 'src', relativePath.replace(/\.vue$/, '.js')))
      continue
    }

    const content = fs.readFileSync(inputPath)
    const outputPath = path.join(outputRoot, 'src', relativePath)
    fs.mkdirSync(path.dirname(outputPath), { recursive: true })

    if (entry.name.endsWith('.js')) {
      fs.writeFileSync(outputPath, fixLocalImports(content.toString('utf8')))
    } else {
      fs.writeFileSync(outputPath, content)
    }
  }
}

processDirectory(sourceRoot)

const indexHtml = fs.readFileSync(path.join(projectRoot, 'index.html'), 'utf8').replace(
  '<script type="module" src="/src/main.js"></script>',
  `<script type="importmap">\n      { "imports": { "vue": "/vendor/vue.esm-browser.js" } }\n    </script>\n    <script type="module" src="/src/main.js"></script>`
)

fs.writeFileSync(path.join(outputRoot, 'index.html'), indexHtml)

const environment = readEnvironmentFile()
fs.writeFileSync(
  path.join(outputRoot, 'config.js'),
  `window.PASTEHUB_CONFIG = ${JSON.stringify(environment, null, 2)};\n`
)

fs.copyFileSync(
  path.join(projectRoot, 'node_modules/vue/dist/vue.esm-browser.prod.js'),
  path.join(outputRoot, 'vendor/vue.esm-browser.js')
)

console.log('Frontend built successfully in dist/.')
