# PasteHub Frontend

Frontend Vue cho đề tài **Pastebin & Code Snippet Sharer** của môn AMD201.

## Các chức năng đã hoàn thiện

- Tạo paste từ code hoặc plain text.
- Kiểm tra nội dung rỗng và giới hạn tối đa 500 KB.
- Chọn ngôn ngữ, thời gian hết hạn: 1 giờ, 1 ngày, 1 tuần hoặc không hết hạn.
- Chọn Public hoặc Private.
- Tạo short code và mở trang `/p/{code}`.
- Hiển thị code có syntax highlighting và line number.
- Copy code và copy share link.
- Public paste feed, tìm kiếm, lọc ngôn ngữ và phân trang.
- Đăng ký, đăng nhập và đăng xuất.
- Dashboard liệt kê paste của tài khoản, thống kê view, tìm kiếm, lọc và xóa.
- Client-side diff viewer so sánh hai paste theo từng dòng.
- Responsive cho desktop, tablet và mobile.
- Dockerfile multi-stage để build và chạy bằng Nginx.

## Chạy nhanh trong Visual Studio hoặc Terminal

Yêu cầu: Node.js 20 trở lên.

```bash
npm install
npm run dev
```

Sau đó mở:

```text
http://localhost:5173
```

Dừng chương trình bằng `Ctrl + C`.

## Tài khoản demo

```text
Email: demo@pastehub.dev
Password: demo123
```

Mặc định frontend chạy ở **demo mode**. Dữ liệu được lưu trong `localStorage`, vì vậy có thể trình diễn giao diện mà không cần khởi động backend hoặc PostgreSQL.

## Kết nối với ASP.NET Core backend

Sao chép file cấu hình:

```bash
copy .env.example .env
```

Trên macOS/Linux:

```bash
cp .env.example .env
```

Sửa `.env`:

```env
VITE_USE_MOCK_API=false
VITE_API_URL=http://localhost:5231/api
```

Sau đó chạy lại:

```bash
npm run dev
```

Frontend hiện tương thích với các API đã có trong backend:

```text
POST   /api/pastes
GET    /api/pastes
GET    /api/pastes/{code}
DELETE /api/pastes/{code}
```

Các màn hình Login, Register và Private Paste đã được làm đầy đủ ở frontend. Để chúng hoạt động an toàn ở real API mode, backend cần bổ sung:

```text
POST /api/auth/register
POST /api/auth/login
GET  /api/pastes/mine
JWT authentication và owner authorization
```

Backend cũng cần bật CORS cho `http://localhost:5173`.

## Build production

```bash
npm run build
npm run preview
```

Bản build nằm trong thư mục `dist` và được xem tại:

```text
http://localhost:4173
```

## Chạy bằng Docker

```bash
docker build -t pastehub-frontend .
docker run --rm -p 8080:80 pastehub-frontend
```

Mở:

```text
http://localhost:8080
```

## Cấu trúc code chính

```text
src/
├── components/
│   ├── AppHeader.vue       # Thanh điều hướng
│   └── PasteCard.vue       # Card hiển thị paste
├── services/
│   ├── api.js              # Chọn mock API hoặc ASP.NET API
│   └── mockApi.js          # Dữ liệu demo bằng localStorage
├── stores/
│   └── auth.js             # Trạng thái đăng nhập
├── utils/
│   ├── format.js           # Format ngày, size và language
│   └── highlight.js        # Syntax highlighting đơn giản
├── views/
│   ├── CreatePasteView.vue
│   ├── PasteView.vue
│   ├── PublicPastesView.vue
│   ├── DashboardView.vue
│   ├── LoginView.vue
│   ├── RegisterView.vue
│   └── DiffView.vue
├── App.vue
├── main.js
├── router.js               # Hash router đơn giản
└── style.css
```

Code không dùng Axios, Vue Router, UI framework hoặc icon package. Mục đích là giảm dependency và giúp luồng chương trình dễ đọc, dễ trình bày với giảng viên.

## Ảnh giao diện

- `preview/home.png`
- `preview/dashboard.png`

## Lưu ý về assignment

Frontend đã bao phủ các màn hình bắt buộc: paste editor, paste view và dashboard. Syntax highlighting, view counter display, public feed có pagination và diff viewer cũng đã có. Private paste ở real deployment vẫn cần backend JWT kiểm tra quyền truy cập; frontend không thể tự bảo vệ dữ liệu nếu API server chưa có authorization.
